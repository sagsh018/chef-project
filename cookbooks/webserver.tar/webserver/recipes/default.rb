#
# Cookbook Name:: webserver
# Recipe:: default
#
# Copyright (c) 2020 The Authors, All Rights Reserved.
include_recipe "webserver::server"